class Worker:
    def __init__(self, name, gender, salary):
        self.name = name
        self.gender = gender
        self.salary = salary
        self.employee_level = None

def generate_workers(num_workers):
    workers = []
    genders = ['Male', 'Female']
    for i in range(num_workers):
        name = f'Worker {i+1}'
        gender = random.choice(genders)
        salary = random.uniform(5000, 40000)  # Random salary between $5000 and $40000
        workers.append(Worker(name, gender, salary))
    return workers

def assign_employee_level(worker):
    if 10000 < worker.salary < 20000:
        worker.employee_level = "A1"
    elif 7500 < worker.salary < 30000 and worker.gender == 'Female':
        worker.employee_level = "A5-F"

def generate_payment_slips(workers):
    for worker in workers:
        try:
            assign_employee_level(worker)
            print(f"Name: {worker.name}, Salary: ${worker.salary}, Employee Level: {worker.employee_level}")
        except Exception as e:
            print(f"Error occurred for {worker.name}: {str(e)}")

if __name__ == "__main__":
    num_workers = 400
    workers = generate_workers(num_workers)
    generate_payment_slips(workers)
